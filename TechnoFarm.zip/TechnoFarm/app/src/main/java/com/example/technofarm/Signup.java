package com.example.technofarm;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Signup extends AppCompatActivity {

    private EditText user,emails,pass,confirms;
    private Button registerBtn;
    private TextView register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        setupUIViews();

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String username = user.getText().toString();
                final String email = emails.getText().toString();
                final String password = pass.getText().toString();
                final String confirm = confirms.getText().toString();


                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            if(validate()){
                                if(success){
                                    startActivity(new Intent(Signup.this,MainActivity.class));
                                }
                                else{
                                    AlertDialog.Builder builder = new AlertDialog.Builder(Signup.this);
                                    builder.setMessage("The password doesn't match")
                                            .setNegativeButton("Retry",null)
                                            .create()
                                            .show();
                                }

                            }
                            else{
                                //Toast.makeText(sign_up.this,"Failed Insert",Toast.LENGTH_SHORT).show();
                                AlertDialog.Builder builder = new AlertDialog.Builder(Signup.this);
                                builder.setMessage("Please Fill up all the Data")
                                        .setNegativeButton("Retry",null)
                                        .create()
                                        .show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };

                RegisterRequest registerRequest = new RegisterRequest(username,email,password,confirm,responseListener);
                RequestQueue queue = Volley.newRequestQueue(Signup.this);
                queue.add(registerRequest);
            }
        });
    }

    private void setupUIViews(){
        user = findViewById(R.id.txtUser);
        emails = findViewById(R.id.txtEmail);
        pass = findViewById(R.id.txtPass);
        confirms = findViewById(R.id.txtConfirm);
        registerBtn = findViewById(R.id.btnSubmit);
        register = findViewById(R.id.tvSubmit);

    }

    private boolean validate(){
        Boolean res = false;

        String pass1 = pass.getText().toString().trim();
        String pass2 = confirms.getText().toString().trim();
        String users = user.getText().toString().trim();
        String email = emails.getText().toString().trim();

        if(pass1.isEmpty() ||pass2.isEmpty() || users.isEmpty() || email.isEmpty() ){
            res = false;
        }
        else{
            res = true;
        }

        return res;
    }
    /*private boolean validateEmail(EditText p_editText, String p_nullMsg, String p_invalidMsg)
    {
              boolean m_isValid = false;
              try
              {
                         if (p_editText != null)
                         {
                         if(validateForNull(p_editText, p_nullMsg ))
                         {
                         Pattern m_pattern = Pattern.compile( "([\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Za-z]{2,4})" );
                         Matcher m_matcher = m_pattern.matcher( p_editText.getText().toString().trim() );

                         if (!m_matcher.matches() & amp; &amp; p_editText.getText().toString().trim().length() & gt;0)
                    {
                        m_isValid = false;
                        p_editText.setError( p_invalidMsg );
                    }
                    else
                    {
                        m_isValid = true;
                    }
                }
                m_isValid = false;
            }
        }
        else
        {
            m_isValid = false;
        }
    }
    catch(Throwable p_e)
    {
        p_e.printStackTrace();

                }
                return m_isValid;

            }
        }

    }*/
   /* private boolean validateEmail(EditText p_editText, String p_nullMsg, String p_invalidMsg)
    {
        boolean m_isValid = false;
        try
        {
            if(p_editText != null) {
                if (validateForNull( p_editText, p_nullMsg )) {
                    Pattern m_pattern = Pattern.compile( "([\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Za-z]{2,4})" );
                    Matcher m_matcher = m_pattern.matcher( p_editText.getText().toString().trim() );
                    if ( !m_matcher.matches() & amp;&amp;
                    p_editText.getText().toString().trim().length() & gt;
                    0)
                    {
                        m_isValid = false;
                        p_editText.setError( p_invalidMsg );
                    }
                    else
                    {
                        m_isValid = true;
                    }
                } else {
                    m_isValid = false;
                }
            }
            else
            {
                m_isValid = false;}

        }
                }
            }

        }*/
    }


