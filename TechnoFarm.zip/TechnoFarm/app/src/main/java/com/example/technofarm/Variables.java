package com.example.technofarm;

public class Variables {
    private String waterlevel;
    private String status;
    private String date;

    public Variables(String waterlevel, String status, String date) {
        this.waterlevel = waterlevel;
        this.status = status;
        this.date = date;
    }

    public String getWaterlevel() {
        return waterlevel;
    }

    public void setWaterlevel(String waterlevel) {
        this.waterlevel = waterlevel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
