package com.example.technofarm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LandingPage extends AppCompatActivity {
    private Button btnAnalytics, btnWaterLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_landing_page );

        btnAnalytics = (Button) findViewById(R.id.btnAnalytics);

        btnAnalytics.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LandingPage.this, Analytics.class);
                startActivity(intent);
            }
        } );


    }
}
