package com.example.technofarm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HeaderLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_header_layout );
    }
}
